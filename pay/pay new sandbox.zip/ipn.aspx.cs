﻿using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Text;
using System;
using payment_cc;
using System.Globalization;

using System.Security.Cryptography.X509Certificates;
public partial class response : System.Web.UI.Page
{
    cls_payment_req_response_prp obj_cls_prp = new cls_payment_req_response_prp();
    cls_payment_req_response obj_cls = new cls_payment_req_response();
     protected void Page_Load(object sender, EventArgs e)
    {

        ServicePointManager.Expect100Continue = true;

        ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3;

        HttpWebRequest req = (HttpWebRequest)WebRequest.Create("https://www.sandbox.paypal.com/cgi-bin/webscr");

        //Header Settings

        req.Method = "POST"; // Post method

        req.ContentType = "text/xml";// content type

        req.KeepAlive = false;

        req.ProtocolVersion = HttpVersion.Version10;

        //Certificate with private key

        //X509Certificate2 cert = new X509Certificate2("Cert.der","Password");

        //req.ClientCertificates.Add(cert);

        req.PreAuthenticate = true;

        String XML = "Test Message";//reader.ReadToEnd();

        byte[] buffer = Encoding.ASCII.GetBytes(XML);

        req.ContentLength = buffer.Length;

        // Wrap the request stream with a text-based writer

        Stream writer = req.GetRequestStream();

        // Write the XML text into the stream

        writer.Write(buffer, 0, buffer.Length);

        writer.Close();

        WebResponse rsp = req.GetResponse();

        StreamReader streamIn = new StreamReader(rsp.GetResponseStream());
        string strResponse = streamIn.ReadToEnd();
        streamIn.Close();


        NumberFormatInfo info2 = new NumberFormatInfo();
        info2.NumberDecimalSeparator = ".";
        info2.NumberGroupSeparator = ",";
        info2.NumberGroupSizes = new int[] { 3 };


        if (strResponse == "VERIFIED")
        {
            Label1.Text = "VERIFIED";

            Label1.Text ="Thanks ";
            //Label1.Text = "transaction id" + Request.Form["txn_id"] + " Mc Gross : " + Convert.ToDecimal(Request.Form["mc_gross"], info2) + "Payer Email:  " + Request.Form["payer_email"] + " First Name : " + Request.Form["first_name"] +
            //    " Last NAme : " + Request.Form["last_name"] + " Address Street : " + Request.Form["address_street"] + "Address City :  " + Request.Form["address_city"] + " State :" +
            //    Request.Form["address_state"] + " Address Zip " + Request.Form["address_zip"] + " Country : " + Request.Form["address_country"] +
            //    " Custom : " + Request.Form["custom"] + "bussinus val :" + Request.Form["business"] + " Payer ID Val : " + Request.Form["payer_id"] +
            //    " Item Number val " + Request.Form["item_number"] + " Item Name  val" + Request.Form["item_name"] + " txt Type val  :" + Request.Form["txn_type"] +
            //    " Pay Status : " + Request.Form["payment_status"] + " reson Val : " + Request.Form["pending_reason"] + " Pay Type val " +
            //    Request.Form["payment_type"] + " Mc Fee val : " + Convert.ToDecimal(Request.Form["mc_fee"], info2) + " Cur val : " + Request.Form["mc_currency"] + " Pay Date Val : " + Request.Form["payment_date"] + "da " + Request.Form["verify_sign"];


            try
            {
                if (Request.Form["txn_id"].ToString() == "" || Request.Form["txn_id"].ToString() == null)
                {
                    obj_cls_prp.txn_id = "";
                }
                else
                {
                    obj_cls_prp.txn_id = Request.Form["txn_id"].ToString();
                }
            }
            catch
            {
                obj_cls_prp.txn_id = "";
            }

            obj_cls_prp.payment_date = DateTime.Now;



            try
            {
                if (Request.Form["payer_email"].ToString() == "" || Request.Form["payer_email"].ToString() == null)
                {
                    obj_cls_prp.payer_email = "";
                }
                else
                {
                    obj_cls_prp.payer_email = Request.Form["payer_email"].ToString();
                }
            }
            catch
            {
                obj_cls_prp.payer_email = "";

            }


            //if (Request.Form["business"].ToString() == "" || Request.Form["business"].ToString() == null)
            //{
            //    obj_cls_prp.business = "";
            //}
            //else
            //{
            //    obj_cls_prp.business = Request.Form["business"].ToString();
            //}
            obj_cls_prp.business = "";

            try
            {
                if (Request.Form["payer_id"].ToString() == "" || Request.Form["payer_id"].ToString() == null)
                {
                    obj_cls_prp.payer_id = "";
                }
                else
                {
                    obj_cls_prp.payer_id = Request.Form["payer_id"].ToString();
                }
            }
            catch
            {
                obj_cls_prp.payer_id = "";
            }

            try
            {
                if (Request.Form["item_number"].ToString() == "" || Request.Form["item_number"].ToString() == null)
                {
                    obj_cls_prp.item_number = "";
                }
                else
                {
                    obj_cls_prp.item_number = Request.Form["item_number"].ToString();
                }

            }
            catch
            {
                obj_cls_prp.item_number = "";
            }


            try
            {

                if (Request.Form["item_name"].ToString() == "" || Request.Form["item_name"].ToString() == null)
                {
                    obj_cls_prp.item_name = "";
                }
                else
                {
                    obj_cls_prp.item_name = Request.Form["item_name"].ToString();
                }
            }
            catch
            {
                obj_cls_prp.item_name = "";
            }



            try
            {
                if (Request.Form["txn_type"].ToString() == "" || Request.Form["txn_type"].ToString() == null)
                {
                    obj_cls_prp.txn_type = "";
                }
                else
                {
                    obj_cls_prp.txn_type = Request.Form["txn_type"].ToString();
                }

            }
            catch
            {
                obj_cls_prp.txn_type = "";
            }

            try
            {
                if (Request.Form["payment_status"].ToString() == "" || Request.Form["payment_status"].ToString() == null)
                {
                    obj_cls_prp.payment_status = "";
                }
                else
                {
                    obj_cls_prp.payment_status = Request.Form["payment_status"].ToString();
                }

            }
            catch
            {
                obj_cls_prp.payment_status = "";
            }


            try
            {
                if (Request.Form["pending_reason"].ToString() == "" || Request.Form["pending_reason"].ToString() == null)
                {
                    obj_cls_prp.pending_reason = "";
                }
                else
                {
                    obj_cls_prp.pending_reason = Request.Form["pending_reason"].ToString();
                }
            }
            catch
            {
                obj_cls_prp.pending_reason = "";
            }


            try
            {

                if (Request.Form["payment_type"].ToString() == "" || Request.Form["payment_type"].ToString() == null)
                {
                    obj_cls_prp.payment_type = "";

                }
                else
                {
                    obj_cls_prp.payment_type = Request.Form["payment_type"];

                }
            }
            catch
            {
                obj_cls_prp.payment_type = "";

            }

            try
            {
                if (Request.Form["mc_gross"].ToString() == "" || Request.Form["mc_gross"].ToString() == null)
                {
                    obj_cls_prp.mc_gross = -1;
                }
                else
                {
                    obj_cls_prp.mc_gross = Convert.ToDecimal(Request.Form["mc_gross"], info2);
                }
            }
            catch
            {
                obj_cls_prp.mc_gross = -1;
            }

            try
            {

                if ((Convert.ToDecimal(Request.Form["mc_fee"], info2)).ToString() == "" || (Convert.ToDecimal(Request.Form["mc_fee"], info2)).ToString() == null)
                {
                    obj_cls_prp.mc_fee = -1;
                }
                else
                {
                    obj_cls_prp.mc_fee = Convert.ToDecimal(Request.Form["mc_fee"], info2);
                }

            }
            catch
            {
                obj_cls_prp.mc_fee = -1;
            }

            try
            {
                if (Request.Form["mc_currency"].ToString() == "" || Request.Form["mc_currency"].ToString() == null)
                {
                    obj_cls_prp.mc_currency = "";

                }
                else
                {
                    obj_cls_prp.mc_currency = Request.Form["mc_currency"].ToString();

                }
            }
            catch
            {
                obj_cls_prp.mc_currency = "";

            }

            try
            {
                if (Request.Form["first_name"].ToString() == "" || Request.Form["first_name"].ToString() == null)
                {
                    obj_cls_prp.buy_first_name = "";
                }
                else
                {
                    obj_cls_prp.buy_first_name = Request.Form["first_name"].ToString();

                }
            }
            catch
            {
                obj_cls_prp.buy_first_name = "";
            }

            try
            {
                if (Request.Form["last_name"].ToString() == "" || Request.Form["last_name"].ToString() == null)
                {
                    obj_cls_prp.buy_last_name = "";
                }
                else
                {
                    obj_cls_prp.buy_last_name = Request.Form["last_name"].ToString();
                }
            }
            catch
            {
                obj_cls_prp.buy_last_name = "";
            }

            try
            {
                if (Request.Form["address_street"].ToString() == "" || Request.Form["address_street"].ToString() == null)
                {
                    obj_cls_prp.buy_address_street = "";
                }
                else
                {
                    obj_cls_prp.buy_address_street = Request.Form["address_street"].ToString();
                }

            }
            catch
            {
                obj_cls_prp.buy_address_street = "";
            }


            try
            {
                if (Request.Form["address_city"].ToString() == "" || Request.Form["address_city"].ToString() == null)
                {
                    obj_cls_prp.buy_address_city = "";
                }
                else
                {
                    obj_cls_prp.buy_address_city = Request.Form["address_city"];
                }
            }
            catch
            {
                obj_cls_prp.buy_address_city = "";
            }



            try
            {
                if (Request.Form["address_state"].ToString() == "" || Request.Form["address_state"].ToString() == null)
                {
                    obj_cls_prp.buy_address_state = "";
                }
                else
                {
                    obj_cls_prp.buy_address_state = Request.Form["address_state"].ToString();
                }
            }
            catch
            {
                obj_cls_prp.buy_address_state = "";
            }


            try
            {
                if (Request.Form["address_zip"].ToString() == "" || Request.Form["address_zip"].ToString() == null)
                {
                    obj_cls_prp.buy_address_zip = "";
                }
                else
                {
                    obj_cls_prp.buy_address_zip = Request.Form["address_zip"].ToString();
                }

            }
            catch
            {
                obj_cls_prp.buy_address_zip = "";
            }

            try
            {

                if (Request.Form["address_country"].ToString() == "" || Request.Form["address_country"].ToString() == null)
                {
                    obj_cls_prp.buy_address_country = "";
                }
                else
                {
                    obj_cls_prp.buy_address_country = Request.Form["address_country"].ToString();
                }
            }
            catch
            {
                obj_cls_prp.buy_address_country = "";
            }


            try
            {
                if (Request.Form["verify_sign"].ToString() == "" || Request.Form["verify_sign"].ToString() == null)
                {
                    obj_cls_prp.verify_sign = "";
                }
                else
                {
                    obj_cls_prp.verify_sign = Request.Form["verify_sign"].ToString();
                }
            }
            catch
            {
                obj_cls_prp.verify_sign = "";
            }


            try
            {
                if (Request.Form["payment_date"].ToString() == "" || Request.Form["payment_date"].ToString() == null)
                {
                    obj_cls_prp.pay_res_date = "";
                }
                else
                {
                    obj_cls_prp.pay_res_date = Request.Form["payment_date"].ToString();
                }
            }
            catch
            {
                obj_cls_prp.pay_res_date = "";
            }
           
            obj_cls_prp.str_out_Response="VERIFIED";
            obj_cls_prp.out_flag_val = "DONE";


            try
            {
                if ( Request.Form["custom"].ToString() == "" ||  Request.Form["custom"].ToString() == null)
                {
                    obj_cls_prp.req_id = 0;
                }
                else
                {
                    obj_cls_prp.req_id = Convert.ToInt32(Request.Form["custom"].ToString());
                }
            }
            catch
            {
                 obj_cls_prp.req_id =0;
            }

           
            obj_cls.save_payment_req_response(obj_cls_prp);


        }
        else if (strResponse == "INVALID")
        {
            //log for manual investigation
            Label1.Text = "INVALID";
        }
        else
        {
            //log response/ipn data for manual investigation
        }
    }
   public void save_rec(string txn_id, decimal mc_gross, string payer_email, string first_name, string last_name, string address_street, string address_city, string address_state, string address_zip, string address_country, string custom, string tf_val, string output)
   {

       //string s_txn_id = "";
       //string s_payment_date = "";
       //string s_payer_email = "";
       //string s_business = "";
       //string s_payer_id = "";
       //string s_item_number = "";
       //string s_item_name = "";
       //string s_txn_type = "";
       //string s_payment_status = "";
       //string s_pending_reason = "";
       //string s_payment_type = "";
       //string s_mc_gross = "";
       //string s_mc_fee = "";
       //string s_mc_currency = "";
       //string s_buy_first_name = "";
       //string s_buy_last_name = "";
       //string s_buy_address_street = "";
       //string s_buy_address_city = "";
       //string s_buy_address_state = "";
       //string s_buy_address_zip = "";
       //string s_buy_address_country = "";
       //string s_verify_sign = "";
        

       obj_cls_prp.txn_id = txn_id;
       obj_cls_prp.payment_date = DateTime.Now; // DateTime.Parse(Request.Form["payment_date"]).Date;
       obj_cls_prp.payer_email = payer_email;
       obj_cls_prp.business = "";
       obj_cls_prp.payer_id = "";
       obj_cls_prp.item_number = "";
       obj_cls_prp.item_name = "";
       obj_cls_prp.txn_type = "";
       obj_cls_prp.payment_status = "";
       obj_cls_prp.pending_reason = "";
       obj_cls_prp.payment_type = "";
       obj_cls_prp.mc_gross = mc_gross;//Request.Form["mc_gross"];
       obj_cls_prp.mc_fee = mc_gross;//Request.Form["mc_fee"];
       obj_cls_prp.mc_currency = "mc_currency";
       obj_cls_prp.buy_first_name = first_name;
       obj_cls_prp.buy_last_name = last_name;
       obj_cls_prp.buy_address_street = address_street;
       obj_cls_prp.buy_address_city = address_city;
       obj_cls_prp.buy_address_state = address_state;
       obj_cls_prp.buy_address_zip = address_zip;
       obj_cls_prp.buy_address_country = address_country;
       obj_cls_prp.verify_sign = "verify_sign";
       obj_cls.save_payment_req_response(obj_cls_prp);

   }
   public string business { get; set; }
}


//transaction id5H891813V1983151W Mc Gross : 400.00 Payer Email: devbu@gmail.com First Name : Dev Bu Last NAme : Kumar Address Street : Address City : State : Address Zip Country : Custom : 78999633
//transaction id9B699112LN8655724 Mc Gross : 400.00Payer Email: devbu@gmail.com First Name : Dev Bu Last NAme : Kumar Address Street : Address City : State : Address Zip Country : Custom : 78999633bussinus val : Payer ID Val : ZGGYQ47G7S8AC Item Number val 1234 Item Name valItem name txt Type val :web_accept Pay Status : Pending reson Val : unilateral Pay Type val instant Mc Fee val : 0 Cur val USD
//                "INVALID payment's parameters" + "(receiver_email or txn_type)");






//            Label1.Text += Request.Form["txn_id"].ToString() + Request.Form["receiver_email"].ToString();

//  Label1.Text += Request.Form["txn_id"].ToString() + Request.Form["receiver_email"].ToString() +
//       Request.Form["txn_id"] + Request.Form["payer_email"] + Request.Form["first_name"] + Request.Form["last_name"] + Request.Form["address_street"] + Request.Form["address_city"]+ Request.Form["address_state"]+ Request.Form["address_zip"] + Request.Form["address_country"] + Request.Form["item_name"] + Request.Form["item_number"] + Request.Form["payment_id"]  + Request.Form["custom"] +   Request.Form["request_id"] ;
         
            


     //string requestUriString;
     //   CultureInfo provider = new CultureInfo("en-us");


     //   string strFormValues = Encoding.ASCII.GetString(
     //       this.Request.BinaryRead(this.Request.ContentLength));


     //   requestUriString = "https://www.sandbox.paypal.com/cgi-bin/webscr";

     //   // Create the request back
     //   HttpWebRequest request = (HttpWebRequest)WebRequest.Create(requestUriString);

     //   // Set values for the request back
     //   request.Method = "POST";
     //   request.ContentType = "application/x-www-form-urlencoded";
     //   string obj2 = strFormValues + "&cmd=_notify-validate";
     //   request.ContentLength = obj2.Length;




     //   //send the request, read the response
     //   HttpWebResponse response = (HttpWebResponse)request.GetResponse();
     //   Stream responseStream = response.GetResponseStream();
     //   Encoding encoding = Encoding.GetEncoding("utf-8");
     //   StreamReader reader = new StreamReader(responseStream, encoding);

     //   // Reads 256 characters at a time.

     //   char[] buffer = new char[0x101];
     //   int length = reader.Read(buffer, 0, 0x100);
     //   while (length > 0)
     //   {
     //       // Dumps the 256 characters to a string

     //       string requestPrice;
     //       string IPNResponse = new string(buffer, 0, length);
     //       length = reader.Read(buffer, 0, 0x100);


     //       NumberFormatInfo info2 = new NumberFormatInfo();
     //       info2.NumberDecimalSeparator = ".";
     //       info2.NumberGroupSeparator = ",";
     //       info2.NumberGroupSizes = new int[] { 3 };

     //       // if the request is verified
     //       if (String.Compare(IPNResponse, "VERIFIED", false) == 0)
     //       {
     //           // check the receiver's e-mail (login is user's
     //           // identifier in PayPal)
     //           // and the transaction type
     //           if ((String.Compare(this.Request["receiver_email"], this.business, false) != 0) || (String.Compare(this.Request["txn_type"], "web_accept", false) != 0))
     //           {
     //               try
     //               {
     //                   // parameters are not correct. Write a
     //                   // response from PayPal
     //                   // and create a record in the Log file.
     //                   save_rec(this.Request["txn_id"], Convert.ToDecimal(this.Request["mc_gross"], info2), this.Request["payer_email"], this.Request["first_name"],
     //                       this.Request["last_name"],
     //                       this.Request["address_street"],
     //                       this.Request["address_city"],
     //                       this.Request["address_state"],
     //                       this.Request["address_zip"],
     //                       this.Request["address_country"],
     //                      this.Request["custom"], "false",
     //                       "INVALID payment's parameters" + "(receiver_email or txn_type)");

     //               }
     //               catch (Exception exception)
     //               {

     //               }
     //               reader.Close();
     //               response.Close();
     //               return;
     //           }


     //           try
     //           {
     //               // write a response from PayPal
     //               save_rec(this.Request["txn_id"],
     //                   Convert.ToDecimal(this.Request["mc_gross"], info2),
     //                   this.Request["payer_email"],
     //                   this.Request["first_name"],
     //                   this.Request["last_name"],
     //                   this.Request["address_street"],
     //                   this.Request["address_city"],
     //                   this.Request["address_state"],
     //                   this.Request["address_zip"],
     //                   this.Request["address_country"],
     //                  this.Request["custom"], "true", "");

     //               ///////////////////////////////////////////////////
     //               // Here we notify the person responsible for
     //               // goods delivery that
     //               // the payment was performed and providing
     //               // him with all needed information about
     //               // the payment. Some flags informing that
     //               // user paid for a services can be also set here.
     //               // For example, if user paid for registration
     //               // on the site, then the flag should be set
     //               // allowing the user who paid to access the site
     //               //////////////////////////////////////////////////
     //           }
     //           catch (Exception exception)
     //           {

     //           }
     //       }
     //       else
     //       {

     //       }
     //   }
     //   reader.Close();
     //   response.Close();