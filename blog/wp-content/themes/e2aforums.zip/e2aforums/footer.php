<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>

<div class="footer">
        <div class="container">
            <div class="row"> 
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 apps">
                <a href="#"><img alt="" class="img-responsive" src="<?php bloginfo('template_directory');?>/images/footer_logo.png"></a>
                <ul class="playstore">
                    <li><a href="#"><img alt="" class="img-responsive" src="<?php bloginfo('template_directory');?>/images/appstore.png"></a></li>
                    <li><a href="#"><img alt="" class="img-responsive" src="<?php bloginfo('template_directory');?>/images/googleplay.png"></a></li>
                </ul>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 categories">
                <h3>Quick Links</h3>
                <ul class="form_categories">
                  <li><a href="http://e2aforums.com/">HOME</a></li>
                  <li><a href="AboutUs.aspx">ABOUT US</a></li>
                  <li><a href="WhyUs.aspx">WHY E2A FORUMS</a></li>
                  <li><a href="Pricing.aspx">PRICING</a></li>
                  <li><a href="Support.aspx">SUPPORT</a></li>
                </ul>

                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 map">
                <a href="#"><img alt="" class="img-responsive" src="<?php bloginfo('template_directory');?>/images/map.png"></a>               
                </div>  
                <div class="col-lg-3 col-md-3 col-sm-3 contacts">
                <ul class="social_icons">
                    <li><a href="https://twitter.com/e2aforums"><img alt="" class="img-responsive" src="<?php bloginfo('template_directory');?>/images/twitter.png"></a></li>
                    <li><a href="https://www.facebook.com/join.e2aforums"><img alt="" class="img-responsive" src="<?php bloginfo('template_directory');?>/images/fb.png"></a></li>
                </ul>
                <h3>Contact Us</h3>
                <ul class="information">
        
                    <li><a href="#"><b>Toll Free:</b> +1-888-280-7780</a></li>
                    <li><a href="#"><b>Email:</b> info@e2aforums.com</a></li>
                    <li><a href="#"><b>Support:</b> support@e2aforums.com</a></li>
                </ul>               
                </div>
            </div>  
                <div class="copyright">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <ul>
                            <li><a href="#">Privacy  Policy</a></li>
                            <li><a href="#">Terms of Service</a></li>
                        </ul>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <p>2014-15 &copy; e2a Forums</p>
                        
                        </div>
                    </div>
                </div>
            
        </div>
    </div>
    </div>
    <?php wp_footer(); ?>
</body>

</html>